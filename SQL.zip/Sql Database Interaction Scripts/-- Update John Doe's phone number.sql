-- Update John Doe's phone number
UPDATE Patient SET phone = '+1112223333' WHERE name = 'John Doe';
