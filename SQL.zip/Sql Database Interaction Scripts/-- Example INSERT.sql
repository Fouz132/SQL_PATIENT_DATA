-- Example INSERT


INSERT INTO Patient (name, age, gender, phone, aadhar)
VALUES ('Fouziya', 20, 'Female', '+910987654321', '6281-4561-7891'),
       ('Durray', 21, 'Male', '+910987654321', '6289-4561-7891'),
       ('Rocky', 20, 'Male', '+9198946544685', '6282-4561-7891'),
       ('Johnny', 19, 'Female', '+9124564986168', '6283-4561-7891'),
       ('PSPK', 42, 'Male', '+914548668451', '6241-4561-7891');
