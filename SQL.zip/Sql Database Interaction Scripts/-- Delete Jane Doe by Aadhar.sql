-- Delete Jane Doe by Aadhar
DELETE FROM Patient WHERE aadhar = '123-456-789';
