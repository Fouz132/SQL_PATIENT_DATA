-- Retrieve all patients
SELECT * FROM Patient;

-- Retrieve a specific patient by Aadhar
SELECT * FROM Patient WHERE aadhar = '123-456-789';
