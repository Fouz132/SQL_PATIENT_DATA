-- Retrieve all patients
SELECT * FROM Patient;
